import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Get the message body as a string
    def body = message.getBody(java.lang.String) as String

    // Split the CSV data by lines
    def lines = body.split('\n')

    // Extract header, item, and trailer lines dynamically
    def headerData = lines.find { it.startsWith("Header") }?.split(',')
    def trailerData = lines.find { it.startsWith("Trailer") }?.split(',')
    def itemLines = lines.findAll { it.startsWith("Item") }

    // Build the XML dynamically
    def writer = new StringWriter()
    def xmlBuilder = new MarkupBuilder(writer)

    xmlBuilder.Root {
        // Handle the Header section dynamically
        Header {
            if (headerData) {
                headerData[1..-1].eachWithIndex { value, idx -> 
                    def key = "HeaderField${idx + 1}" // You can define your custom logic here
                    "${key}"(value)
                }
            }
        }

        // Handle the Item section dynamically
        itemLines.each { line ->
            def itemData = line.split(',')
            Item {
                itemData[1..-1].eachWithIndex { value, idx -> 
                    def key = "ItemField${idx + 1}" // You can define your custom logic here
                    "${key}"(value)
                }
            }
        }

        // Handle the Trailer section dynamically
        Trailer {
            if (trailerData) {
                trailerData[1..-1].eachWithIndex { value, idx -> 
                    def key = "TrailerField${idx + 1}" // You can define your custom logic here
                    "${key}"(value)
                }
            }
        }
    }

    // Set the built XML as the message body
    message.setBody(writer.toString())
    return message
}
