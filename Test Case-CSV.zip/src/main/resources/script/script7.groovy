import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

Message processData(Message message) {
    // Get the CSV payload from the message body
    def body = message.getBody(String)
    
    // Split the CSV into lines
    def lines = body.split("\n")
    
    // Extract the headers (first line of CSV)
    def headers = lines[0].split(",").collect { it.trim() }
    def expectedFieldCount = headers.size()  // Number of expected fields (based on header)
    
    // Initialize a StringWriter to hold the XML output
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    
    // Create the XML structure for each record
    lines[1..-1].each { line ->
        def fields = line.split(",").collect { it.trim() }
        
        // Handling missing fields: If there are fewer fields, add empty strings
        if (fields.size() < expectedFieldCount) {
            fields += [''] * (expectedFieldCount - fields.size())
        }
        
        // Handling additional fields: If there are more fields, ignore the extras
        if (fields.size() > expectedFieldCount) {
            fields = fields[0..(expectedFieldCount - 1)]
        }
        
        // Construct the XML for each record
        xml.Records {
            headers.eachWithIndex { header, index ->
                "$header"(fields[index])  // Create XML elements for each field
            }
        }
    }
    
    // Set the resulting XML as the message body
    message.setBody(writer.toString())
    
    return message
}
