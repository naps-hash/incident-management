import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Get the message body as a string
    def body = message.getBody(java.lang.String) as String

    // Split the CSV data by lines
    def lines = body.split('\n')

    // Extract header, item, and trailer lines dynamically
    def headerData = lines.find { it.startsWith("Header") }?.split(',')
    def trailerData = lines.find { it.startsWith("Trailer") }?.split(',')
    def itemLines = lines.findAll { it.startsWith("Item") }

    // Build the XML dynamically
    def writer = new StringWriter()
    def xmlBuilder = new MarkupBuilder(writer)

    xmlBuilder.Root {
        // Handle the Header section with specific field names
        Header {
            if (headerData) {
                FileID(headerData[1])   // File field
                Date(headerData[2])     // Date field
                OrderID(headerData[3])  // Order field
            }
        }

        // Handle the Item section with specific field names
        itemLines.each { line ->
            def itemData = line.split(',')
            Item {
                ProductName(itemData[1])  // Product field
                Quantity(itemData[2])     // Number field
                Price(itemData[3])        // Price field
            }
        }

        // Handle the Trailer section with specific field names
        Trailer {
            if (trailerData) {
                TotalItems(trailerData[1])  // Total field
                TotalAmount(trailerData[2]) // Sum field
            }
        }
    }

    // Set the built XML as the message body
    message.setBody(writer.toString())
    return message
}
